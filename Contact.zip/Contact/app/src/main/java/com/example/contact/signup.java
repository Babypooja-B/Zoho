package com.example.contact;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class signup extends AppCompatActivity {
//
//    EditText Email, Password, Secret;
//    Button signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().setTitle("Sign Up");


//        Email = (EditText) findViewById(R.id.email);
//        Password = (EditText) findViewById(R.id.Password);
//        Secret = (EditText) findViewById(R.id.Secret);
//        signup = (Button) findViewById(R.id.signup);
//        signup.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
    }
    public void signup(View view)

    {
        startActivity(new Intent(getApplicationContext(),signin.class));
    }
}